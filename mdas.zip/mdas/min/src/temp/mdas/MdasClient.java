package mdas;

import java.net.*;
import java.io.*;
import java.util.*;
public class MdasClient
{
	private static Socket s;
	private static DataInputStream dis;
	private static DataOutputStream dos;
	private static BufferedReader br;
	private PrintWriter pw;

public static void main(String[] args)
{
	try	{
		  s=new Socket("localhost",1234);
		dis=new DataInputStream(s.getInputStream());
		dos=new DataOutputStream(s.getOutputStream());
	}
	catch(UnknownHostException HO){System.out.println("MdasServer Not Found"+HO);}
	catch(IOException SE){	System.out.println("Socket Failed......"+SE); System.exit(0);}
	

	while(true)
	{
		try
		{
		  System.out.println("\nEnter Message for MDAS Malware Detection "	+"MdasServer....\n");

		  br=new BufferedReader(new InputStreamReader(System.in));
		  String getMsg=br.readLine();
		  dos.writeUTF(getMsg);
		  String respo=dis.readUTF();
		  System.out.println(respo);
		}
		catch(IOException io)
		{
			System.out.println("MdasServer Failed....."+io);
			System.exit(0);
		}
	}
}

}
