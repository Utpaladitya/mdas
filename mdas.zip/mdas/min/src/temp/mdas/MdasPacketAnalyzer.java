/*Author Aditya
 * 
 */


package mdas;
import java.util.*;

import mdas.analytics.*;


public class MdasPacketAnalyzer
{
	static Vector analyzers=new Vector();
	
	static void loadDefaultAnalyzer(){
		analyzers.addElement(new PacketMdas());
		analyzers.addElement(new EthernetMdas());
		analyzers.addElement(new IPv4Mdas());
		analyzers.addElement(new IPv6AMdas());
		analyzers.addElement(new TCPMdas());
		analyzers.addElement(new UDPMdas());
		analyzers.addElement(new ICMPMdas());
		analyzers.addElement(new HTTPMdas());
		analyzers.addElement(new FTPMdas());
		analyzers.addElement(new TelnetMdas());
		analyzers.addElement(new SSHMdas());
		analyzers.addElement(new SMTPMdas());
		analyzers.addElement(new POP3Mdas());
		analyzers.addElement(new ARPMdas());
	}
	
	public static PacketAnalyzerAbstract[] getAnalyzers(){
		PacketAnalyzerAbstract[] array=new PacketAnalyzerAbstract[analyzers.size()];
		
		for(int i=0;i<array.length;i++)
			array[i]=(PacketAnalyzerAbstract)analyzers.elementAt(i);
			
		return array;
	}
	
	public static PacketAnalyzerAbstract[] getAnalyzersOf(int layer){
		Vector v=new Vector();
		
		for(int i=0;i<analyzers.size();i++)
			if(((PacketAnalyzerAbstract)analyzers.elementAt(i)).layer==layer)
				v.addElement(analyzers.elementAt(i));
		
		PacketAnalyzerAbstract[] res=new PacketAnalyzerAbstract[v.size()];
		for(int i=0;i<res.length;i++)
			res[i]=(PacketAnalyzerAbstract)v.elementAt(i);
		
		return res;
	}
}
