/* 
 * Author Utpaladitya
 * 
 * This is the main class that loads the packetsniffer and also loads all the user 
 * interfaces like windows,graphs etc.This class contains the main method of the project.
 *  
*/
package mdas;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Vector;

import javax.swing.JOptionPane;

import mdas.screens.Frame;



public class MdasPacketSniffer
{
	public static Properties JDProperty;
	
	public static javax.swing.JFileChooser chooser=new javax.swing.JFileChooser();

	static Vector frames=new Vector();

	public static void main(String[] args){
		try{
			//System.out.println(System.getProperty("java.library.path"));
			Class c=Class.forName("jpcap.JpcapCaptor");
		}catch(ClassNotFoundException e){
			JOptionPane.showMessageDialog(null,"Cannot find Jpcap. Please download and install Jpcap before running.");
			System.exit(0);
		}
				
		MdasPacketAnalyzer.loadDefaultAnalyzer();
		MdasStatistics.loadStatisticsTaker();
		loadProperty();
		
		openNewWindow();
		
	}
	
	public static void saveProperty(){
		if(JDProperty==null) return;
		try{
			JDProperty.store((OutputStream)new FileOutputStream("JpcapDumper.property"),"JpcapDumper");
			//JDProperty.store(new FileOutputStream("JpcapDumper.property"),"JpcapDumper");
		}catch(IOException e){
		}catch(ClassCastException e){
		}
	}
	
	static void loadProperty(){
		try{
			JDProperty=new Properties();
			JDProperty.load((InputStream)new FileInputStream("JpcapDumper.property"));
		}catch(IOException e){
		}
	}
	
	public static void openNewWindow(){
		Capture capture=new Capture();
		frames.add(Frame.openNewWindow(capture));
	}
	
	public static void closeWindow(Frame frame){
		frame.capture.stopCapture();
		frame.capture.saveIfNot();
		frame.capture.closeAllWindows();
		frames.remove(frame);
		frame.dispose();
		if(frames.isEmpty()){
			saveProperty();
			System.exit(0);
		}
	}
	
	protected void finalize() throws Throwable{
		saveProperty();
	}
}
