package mdas;

import java.net.*;
import java.io.*;
import java.util.*;


public class MdasServer
{
	private static Socket s;
	private static ServerSocket ss;
	static int i=1;

public static void main(String[] args)
{
	try
	{
		ss=new ServerSocket(1234	);
		System.out.println("\nThe MDAS MdasServer\t"+ss.getInetAddress().getLocalHost()+"\tis listening at port\t"+ss.getLocalPort());
		while(true)
		{
			s=ss.accept();
			new threadHandler(s,i).start();
			i++;
		}

	}catch(Exception ioe)
		{
			System.out.println(ioe);
		}


}
}

class threadHandler extends Thread
{
	Socket clientSocket;
	int clientNo;
	DataInputStream dis;
	DataOutputStream dos;
	Hashtable ht=new Hashtable();
	BufferedReader br;

	threadHandler(Socket s, int n)
	{
           clientSocket=s;
	   	   clientNo=n;
		   //System.out.println(clientSocket);  
	       System.out.println("MdasClient No  "+ clientNo+clientSocket.getPort()+ " has logged in");
	}

	public void run()
	{
		while(true)
		{
		try
		{

		dis=new DataInputStream(clientSocket.getInputStream());
		dos=new DataOutputStream(clientSocket.getOutputStream());
		String recd=dis.readUTF();
		System.out.println(recd);
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\n\nType Message for MdasClient...\n");
		String fromServer=br.readLine();

		dos.writeUTF("\nThanks for Joining MDAS......"+fromServer);

		}catch(IOException e){System.out.println(e);}
		}
	}
}


