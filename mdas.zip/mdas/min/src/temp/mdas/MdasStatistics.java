/*Author Aditya
 * 
 * 
 */

package mdas;
import java.util.*;

import mdas.stats.MdasProtocolStat;
import mdas.stats.MemStatMdas;
import mdas.stats.MdasNetworkProtocol;
import mdas.stats.PacketMdas;
import mdas.stats.MdasStatisticsTaker;
import mdas.stats.TransportMdas;


public class MdasStatistics
{
	static Vector stakers=new Vector();
	
	static void loadStatisticsTaker(){
		stakers.addElement(new PacketMdas());
		stakers.addElement(new MdasNetworkProtocol());
		stakers.addElement(new TransportMdas());
		stakers.addElement(new MdasProtocolStat());
		stakers.addElement(new MemStatMdas());
	}
	
	public static MdasStatisticsTaker[] getStatisticsTakers(){
		MdasStatisticsTaker[] array=new MdasStatisticsTaker[stakers.size()];
		
		for(int i=0;i<array.length;i++)
			array[i]=(MdasStatisticsTaker)stakers.elementAt(i);
			
		return array;
	}
	
	public static MdasStatisticsTaker getStatisticsTakerAt(int index){
		return (MdasStatisticsTaker)stakers.get(index);
	}
}
