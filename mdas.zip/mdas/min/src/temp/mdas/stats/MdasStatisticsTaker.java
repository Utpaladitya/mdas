/*This is an abstract class.All the other classes in this pckage extends this class
 * 
 */
package mdas.stats;
import java.util.Vector;
import jpcap.packet.Packet;

public abstract class MdasStatisticsTaker
{
	public abstract String getName();//Gets the name of the 

	public abstract void analyze(Vector packets);
	public abstract void addPacket(Packet p);
	
	public abstract String[] getLabels();
	public abstract String[] getStatTypes();
	public abstract long[] getValues(int index);
	
	public abstract void clear();
	
	public MdasStatisticsTaker newInstance(){
		try{
			return (MdasStatisticsTaker)this.getClass().newInstance();
		}catch(Exception e){
			return null;
		}
	}
}